package com.investing.forecastbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForecastBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
