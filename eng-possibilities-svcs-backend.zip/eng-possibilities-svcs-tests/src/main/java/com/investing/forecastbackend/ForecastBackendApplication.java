package com.investing.forecastbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForecastBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForecastBackendApplication.class, args);
	}

}
