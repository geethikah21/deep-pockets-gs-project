package com.investing.forecastbackend.service;

public class InvestingForecastServiceTest {
}
